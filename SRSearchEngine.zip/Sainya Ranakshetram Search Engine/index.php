<!DOCTYPE html>
	<html>
		<head>
			<meta charset="utf-8">
			<title>Roshan Search Engine</title>
		</head>
		<body>
			<div style="width: 600px; margin: 10px auto">
				<h1 style="text-align: center">Search the Web with my Search Engine</h1>
				<form action="search.php" method="get">
					<input type="text" style="width: 100%; font-size: 16px;" name="q" value="" placeholder="Search the web...">
					<div style="text-align: center"><input type="submit" style="font-size: 16px; margin-top: 10px" name="search" value="Search"></div>
				</form>
			</div>
		</body>
		</html>